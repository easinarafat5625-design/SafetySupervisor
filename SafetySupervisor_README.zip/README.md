# 📱 Safety Supervisor
Construction Safety Supervisor – Learning & Exam Preparation App

Safety Supervisor is a complete offline learning and exam preparation Android app designed for Construction Safety Supervisor candidates.

Key Features:
- Learning Book (Theory)
- 10,000+ MCQ Practice
- Mock Tests
- Progress Tracking
- Bookmarks
- Offline Support

Platform: Android
Language: English
Tech: Kotlin, Room (SQLite)

This project is for educational purposes.
